import tkinter as tk
from tkinter import messagebox

# Motor Labels (order matters since the values will be saved in this order)
motor_labels = [
    "Index - Base",
    "Index - Main Joint",
    "Middle - Base",
    "Middle - Main Joint",
    "Ring - Base",
    "Ring - Main Joint",
    "Little - Base",
    "Little - Main Joint",
    "Thumb - Base",
    "Thumb - Main Joint",
    "Thumb - Stretch",
    "Wrist Motor"
]

# Wipe previous data in data.txt when the program is run
try:
    with open("data.txt", "w") as file:
        file.write("")  # This clears the file
except Exception as e:
    print(f"Warning: Could not clear data.txt: {e}")

# Create the main window
root = tk.Tk()
root.title("Prosthetic Arm Preset Creator")

# Preset Name Entry
tk.Label(root, text="Preset Name:").grid(row=0, column=0, padx=5, pady=5, sticky="e")
preset_name_entry = tk.Entry(root, width=30)
preset_name_entry.grid(row=0, column=1, padx=5, pady=5)

# Create a dictionary to hold the motor entry widgets
entries = {}

# Start adding motor entries from row 1 (or 1 + offset)
start_row = 1
for i, label_text in enumerate(motor_labels):
    tk.Label(root, text=label_text + ":").grid(row=start_row + i, column=0, padx=5, pady=3, sticky="e")
    entry = tk.Entry(root, width=30)
    entry.grid(row=start_row + i, column=1, padx=5, pady=3)
    entries[label_text] = entry

# Function to check entries and write the preset to data.txt
def save_preset():
    preset_name = preset_name_entry.get().strip()
    if not preset_name:
        messagebox.showerror("Input Error", "Please enter a preset name.")
        return

    # Collect and check values for all motors.
    motor_values = []
    for label_text in motor_labels:
        value_str = entries[label_text].get().strip()
        try:
            value_int = int(value_str)
        except ValueError:
            messagebox.showerror("Input Error", f"Please enter a valid integer for '{label_text}'.")
            return

        # Ensure motor values are between 0 and 180
        if value_int < 0 or value_int > 180:
            messagebox.showerror("Input Error", f"Value for '{label_text}' must be between 0 and 180.")
            return

        motor_values.append(value_int)

    # Format as CSV: preset name followed by each motor value
    preset_line = preset_name + "," + ",".join(map(str, motor_values)) + "\n"

    # Attempt to write to data.txt (append mode)
    try:
        with open("data.txt", "a") as file:
            file.write(preset_line)
        messagebox.showinfo("Success", "Preset saved successfully!")
    except Exception as e:
        messagebox.showerror("File Error", f"An error occurred while writing the file:\n{e}")

    # Clear all input fields after saving
    preset_name_entry.delete(0, tk.END)
    for entry in entries.values():
        entry.delete(0, tk.END)

# Save Preset Button
save_button = tk.Button(root, text="Save Preset", command=save_preset)
save_button.grid(row=start_row + len(motor_labels), column=0, columnspan=2, pady=10)

# Start the Tkinter event loop
root.mainloop()
